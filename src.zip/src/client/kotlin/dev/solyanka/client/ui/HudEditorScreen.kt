/* SPDX-License-Identifier: GPL-3.0-only
 * NoFrills HudEditorScreen interaction concepts adapted for solyanka's existing Odin HUDs.
 * Original WhatYouThing and NoFrills contributors; pinned revision and license in NOTICE. */
package dev.solyanka.client.ui

import dev.solyanka.client.SolyankaClient
import dev.solyanka.client.ui.nofrills.GuiKit
import dev.solyanka.ui.*
import dev.solyanka.utility.HudSpec
import io.wispforest.owo.ui.base.BaseOwoScreen
import io.wispforest.owo.ui.container.*
import io.wispforest.owo.ui.core.*
import net.minecraft.client.gui.GuiGraphicsExtractor
import net.minecraft.client.input.MouseButtonEvent
import net.minecraft.client.input.KeyEvent
import net.minecraft.client.Minecraft
import net.minecraft.network.chat.Component
import org.lwjgl.glfw.GLFW
import kotlin.math.min

/** Dedicated layout canvas. Samples never enable modules or alter timer/stat state. */
class HudEditorScreen:BaseOwoScreen<FlowLayout>(Component.literal("solyanka HUD editor")) {
    private val model=InstantSettings(SolyankaClient.currentProfile(),SolyankaClient.currentGeneral()) { p,g ->
        SolyankaClient.applySettings(p,SolyankaClient.states(),g)
    }
    private var selected="timer.goldor"
    private fun select(key:String) {selected=key}
    private var dragging:String?=null
    private var offsetX=0.0;private var offsetY=0.0
    private fun entries()=HudLayout.visibleEntries(SolyankaClient.currentGeneral().features,SolyankaClient.states().filter { (id,enabled)->enabled && SolyankaClient.isEnabled(id) }.keys,width,height).map {dev.solyanka.client.feature.PerformanceHud.editorEntry(dev.solyanka.client.feature.ScoreboardHud.editorEntry(dev.solyanka.client.feature.VanillaHotbar.editorEntry(it,width,height),width))}
    private var controlKeys:List<String> = emptyList()
    private fun syncSelection(list:List<HudEntry>) {if(list.none {it.key==selected}) selected=list.firstOrNull()?.key ?: ""}
    private fun ordered()=entries().sortedBy {it.key==selected}
    private fun bounds(entry:HudEntry)=HudLayout.bounds(entry,entry.lines.maxOf {font.width(it)},width,height)
    private fun at(x:Double,y:Double)=ordered().asReversed().firstOrNull {bounds(it).contains(x,y)}
    private fun change(key:String,scoreboardAnchor:Boolean?=null,block:(HudSpec)->HudSpec) {
        // Always start from live state: an earlier failed write must not leak into a later drag.
        model.updateGeneral {
            val current=SolyankaClient.currentGeneral()
            val f=HudLayout.update(current.features,key,width,height,block)
            current.copy(features=if(key=="extra.scoreboard" && scoreboardAnchor!=null) f.copy(scoreboardHud=f.scoreboardHud.copy(anchorRight=scoreboardAnchor)) else f)
        }
    }
    override fun createAdapter():OwoUIAdapter<FlowLayout> = OwoUIAdapter.create(this) {w,h->UIContainers.verticalFlow(w,h)}
    override fun build(root:FlowLayout) {
        dragging=null
        val list=entries();syncSelection(list);controlKeys=list.map {it.key}
        val controls=UIContainers.horizontalFlow(Sizing.content(),Sizing.content()).apply {
            gap(5);verticalAlignment(VerticalAlignment.BOTTOM)
            positioning(Positioning.absolute((width-175).coerceAtLeast(0),28))
            if(SolyankaClient.isEnabled(SolyankaClient.MOVE_HOTBAR)) child(GuiKit.button("Restore Hotbar",110) {
                model.updateGeneral { SolyankaClient.currentGeneral().let {g->g.copy(features=g.features.copy(moveHotbar=dev.solyanka.utility.HotbarLayout.restore(g.features.moveHotbar)))}}
                select("archive.hotbar")
            })
            if(list.isEmpty()) child(GuiKit.label("No enabled HUDs"))
            child(GuiKit.button("Done",55) {onClose()})
        }
        root.child(controls)
    }
    override fun extractRenderState(g:GuiGraphicsExtractor,mx:Int,my:Int,delta:Float) {
        val current=entries();syncSelection(current)
        if(controlKeys!=current.map {it.key}) {uiAdapter.rootComponent.clearChildren();build(uiAdapter.rootComponent)}
        val hovered=at(mx.toDouble(),my.toDouble())?.key
        ordered().forEach {entry ->
            val b=bounds(entry);val active=entry.hud.enabled
            if(entry.key!="extra.scoreboard") g.fill(b.x,b.y,b.x+b.width,b.y+b.height,if(entry.key==selected) 0x88213946.toInt() else 0x66101010)
            GuiKit.border(g,b.x,b.y,b.width,b.height,if(entry.key==selected || entry.key==hovered) GuiKit.BLUE else 0xff666666.toInt())
            if(dev.solyanka.client.feature.YandexMusic.editor(g,entry.key,b.x,b.y) || dev.solyanka.client.feature.VanillaHotbar.editor(g,entry.key,b.x,b.y) || dev.solyanka.client.feature.VanillaHearts.editor(g,entry.key,b.x,b.y) || dev.solyanka.client.feature.ArchiveHuds.editor(g,entry.key,b.x,b.y) || dev.solyanka.client.feature.ExtraHuds.editor(g,entry.key,b.x,b.y) || dev.solyanka.client.feature.ScoreboardHud.editor(g,entry.key,b.x,b.y)) {
                GuiKit.border(g,b.x,b.y,b.width,b.height,if(entry.key==selected || entry.key==hovered) GuiKit.BLUE else 0xff666666.toInt())
                return@forEach
            }
            // Generic previews (including PiP, pet and player stats) share their owner's glow.
            dev.solyanka.client.feature.HudGlow.draw(g,HudLayout.owner(entry.key),b.x,b.y,b.width,b.height)
            g.pose().pushMatrix()
            try {
                g.pose().translate(b.x+2f,b.y+1f);g.pose().scale(entry.hud.scale.toFloat(),entry.hud.scale.toFloat())
                entry.lines.forEachIndexed {i,line ->g.text(font,Component.literal(line),0,i*10,if(active) entry.hud.color else 0xff888888.toInt(),true)}
            } finally {g.pose().popMatrix()}
        }
        g.text(font,"HUD editor: drag LMB | scroll: scale | RMB: select",5,5,GuiKit.WHITE,true)
        g.text(font,"Enabled modules + visible HUDs only. Enable hidden HUDs in settings.",5,16,GuiKit.WHITE,true)
        val entry=entries().firstOrNull {it.key==selected}
        if(entry!=null) g.text(font,"${entry.name}: ${entry.hud.x}, ${entry.hud.y} | ${entry.hud.scale}x | ${if(entry.hud.enabled) "shown" else "hidden"}",5,(height-57).coerceAtLeast(28),GuiKit.BLUE,true)
        model.error?.let {g.text(font,"Not saved: $it",5,(height-68).coerceAtLeast(39),0xffff5555.toInt(),true)}
        super.extractRenderState(g,mx,my,delta)
    }
    override fun mouseClicked(click:MouseButtonEvent,doubled:Boolean):Boolean {
        if(click.y() in 28.0..51.0 && click.x()>=(width-175).coerceAtLeast(0)) return super.mouseClicked(click,doubled)
        uiAdapter.rootComponent.focusHandler()?.focus(null,UIComponent.FocusSource.MOUSE_CLICK)
        val entry=at(click.x(),click.y()) ?: return true
        select(entry.key)
        if(click.button()==0) {
            val b=bounds(entry);dragging=entry.key;offsetX=click.x()-b.x;offsetY=click.y()-b.y
        } // Right-click only selects. Visibility belongs in module settings, not a destructive editor gesture.
        return true
    }
    override fun mouseDragged(click:MouseButtonEvent,dx:Double,dy:Double):Boolean {
        val key=dragging ?: return super.mouseDragged(click,dx,dy)
        val entry=entries().firstOrNull {it.key==key} ?: run {dragging=null;return true}
        val b=bounds(entry)
        if(key=="extra.scoreboard") {
            val dragged=HudLayout.drag(entry.hud,click.x(),click.y(),offsetX,offsetY,b,width,height)
            val right=(width-b.width).coerceAtLeast(0)
            change(key,right>0 && dragged.x>=right) {dragged}
        } else change(key) {HudLayout.drag(it,click.x(),click.y(),offsetX,offsetY,b,width,height)}
        return true
    }
    override fun mouseReleased(click:MouseButtonEvent):Boolean {
        val wasDragging=dragging!=null;dragging=null
        return if(wasDragging) true else super.mouseReleased(click)
    }
    override fun mouseScrolled(x:Double,y:Double,horizontal:Double,vertical:Double):Boolean {
        if(y in 28.0..51.0 && x>=(width-175).coerceAtLeast(0)) return super.mouseScrolled(x,y,horizontal,vertical)
        val entry=at(x,y) ?: return true
        if(entry.resizable && vertical!=0.0) {
            select(entry.key)
            change(entry.key) {val hotbar=SolyankaClient.currentGeneral().features.moveHotbar
                val ref=if(entry.key=="archive.hotbar")dev.solyanka.utility.HotbarLayout.referenceScale(hotbar,width,height)else 1.0
                val requested=if(entry.key=="archive.hotbar")hotbar.hud.scale else it.scale
                it.copy(scale=NumberRange(.5,4.0,.05).snap(requested+if(vertical>0) .05 else -.05)*ref)}
        }
        return true
    }
    override fun keyPressed(event:KeyEvent):Boolean {
        if(uiAdapter.rootComponent.focusHandler()?.focused()!=null) return super.keyPressed(event)
        val delta=when(event.key()) {GLFW.GLFW_KEY_LEFT->-1 to 0;GLFW.GLFW_KEY_RIGHT->1 to 0;GLFW.GLFW_KEY_UP->0 to -1;GLFW.GLFW_KEY_DOWN->0 to 1;else->return super.keyPressed(event)}
        if(selected.isEmpty()) return true
        if(selected=="extra.scoreboard") {
            val e=entries().firstOrNull {it.key==selected} ?: return true
            val b=bounds(e);val right=(width-b.width).coerceAtLeast(0)
            val x=(b.x+delta.first).coerceIn(0,right);val y=(b.y+delta.second).coerceIn(0,(height-b.height).coerceAtLeast(0))
            change(selected,right>0 && x==right) {it.copy(x=x,y=y)}
        } else change(selected) {it.copy(x=(it.x+delta.first).coerceIn(0,10000),y=(it.y+delta.second).coerceIn(0,10000))}
        return true
    }
    override fun resize(width:Int,height:Int) {dragging=null;super.resize(width,height)}
    override fun removed() {dragging=null;super.removed();dispose();uiAdapter=null}
    override fun onClose() {dragging=null;Minecraft.getInstance().gui.setScreen(null)}
}
