/* SPDX-License-Identifier: GPL-3.0-only */
package dev.solyanka.utility

import com.google.gson.*
import dev.solyanka.ui.*
import org.junit.jupiter.api.Test
import kotlin.test.*
import java.nio.file.Path

class ArchiveDungeonTest {
    @Test fun `secret counter settings migrate with announcements off`() {val f=FeatureCodec.decode(JsonObject());assertEquals(SecretCounterSettings(),f.secretCounter);assertFalse(f.secretCounter.autoAnnounce)}
    @Test fun `both announcement channels roundtrip`() {for(c in listOf("current","party")) {val f=FeatureSettings(secretCounter=SecretCounterSettings(true,c));assertEquals(f,FeatureCodec.decode(Gson().toJsonTree(f).asJsonObject))}}
    @Test fun `unknown channel and wrong types fail validation`() {assertFails {SecretCounterSettings(channel="all").validate()};for(raw in listOf("""{"secretCounter":{"autoAnnounce":1}}""","""{"secretCounter":{"channel":0}}""","""{"secretCounter":{"channel":null}}""")) assertFails {FeatureCodec.decode(JsonParser.parseString(raw).asJsonObject)}}
    @Test fun `announcement threshold is opt in and strictly greater`() {
        val s=SecretCounterSettings(autoAnnounce=true,thresholdEnabled=true,threshold=5)
        assertFalse(s.shouldAnnounce(4));assertFalse(s.shouldAnnounce(5));assertTrue(s.shouldAnnounce(6))
        assertTrue(s.copy(thresholdEnabled=false).shouldAnnounce(0));assertFalse(s.copy(autoAnnounce=false).shouldAnnounce(6))
        assertFails {s.copy(threshold=-1).validate()}
        assertEquals(s,FeatureCodec.decode(Gson().toJsonTree(FeatureSettings(secretCounter=s)).asJsonObject).secretCounter)
    }
    @Test fun `a request is impossible before a completion event`() {val s=SecretCounterState();assertNull(s.poll(0));assertNull(s.poll(100000));assertNull(s.readSecrets("Secrets Found: 42",100000))}
    @Test fun `request waits exactly one second after completion`() {val s=SecretCounterState();s.finish(100);assertNull(s.poll(1099));assertEquals(SecretCounterState.Action.REQUEST_STATS,s.poll(1100));assertNull(s.poll(1101))}
    @Test fun `duplicate finish headers do not postpone or duplicate request`() {val s=SecretCounterState();s.finish(0);s.finish(900);assertEquals(SecretCounterState.Action.REQUEST_STATS,s.poll(1000));s.finish(1100);assertNull(s.poll(2000))}
    @Test fun `only results after the request are accepted`() {val s=SecretCounterState();s.finish(0);assertNull(s.readSecrets("Secrets Found: 11",999));s.poll(1000);assertEquals(11,s.readSecrets("Secrets Found: 11",1001))}
    @Test fun `grouped and color coded server counts parse`() {val s=requested();assertEquals(1234567,s.readSecrets("  §bSecrets Found: §a1,234,567  ",1100))}
    @Test fun `zero personal secrets is a real result`() {val s=requested();assertEquals(0,s.readSecrets("Secrets Found: 0",1100))}
    @Test fun `signed fractional malformed and overflowing counts are ignored`() {for(text in listOf("Secrets Found: -1","Secrets Found: +1","Secrets Found: 1.5","Secrets Found: 1,23","Secrets Found: 1,234,56","Secrets Found: 2147483648","Secrets Found: 999999999999999999999")) {val s=requested();assertNull(s.readSecrets(text,1100),text);assertEquals(2,s.readSecrets("Secrets Found: 2",1200))}}
    @Test fun `maximum integer count does not overflow`() {assertEquals(Int.MAX_VALUE,requested().readSecrets("Secrets Found: 2,147,483,647",1100))}
    @Test fun `party player team totals and percentage lines are not personal results`() {for(text in listOf("Party > Player: Secrets Found: 5","[MVP+] Player: Secrets Found: 5","Team Secrets Found: 5","Secrets Found: 50%","Secrets Found: 5/10","[solyanka] Secrets Found: 5","prefix Secrets Found: 5","Secrets Found: 5 trailing")) assertNull(requested().readSecrets(text,1100),text)}
    @Test fun `exactly one result is consumed per run`() {val s=requested();assertEquals(8,s.readSecrets("Secrets Found: 8",1100));assertNull(s.readSecrets("Secrets Found: 9",1200));assertNull(s.poll(20000));s.finish(21000);assertNull(s.poll(22000))}
    @Test fun `response deadline starts at actual request rather than completion`() {val s=SecretCounterState();s.finish(0);assertEquals(SecretCounterState.Action.REQUEST_STATS,s.poll(5000));assertEquals(9,s.readSecrets("Secrets Found: 9",14999))}
    @Test fun `timeout occurs once at the ten second boundary`() {val s=requested();assertNull(s.poll(10999));assertEquals(SecretCounterState.Action.TIMEOUT,s.poll(11000));assertNull(s.poll(11001));assertNull(s.readSecrets("Secrets Found: 4",11001))}
    @Test fun `result at the deadline is rejected and still reports timeout`() {val s=requested();assertNull(s.readSecrets("Secrets Found: 4",11000));assertEquals(SecretCounterState.Action.TIMEOUT,s.poll(11000))}
    @Test fun `reset cancels an unsent request`() {val s=SecretCounterState();s.finish(0);s.reset();assertNull(s.poll(1000));assertNull(s.readSecrets("Secrets Found: 4",1001))}
    @Test fun `reset cancels a waiting response and permits the next run`() {val s=requested();s.reset();assertNull(s.readSecrets("Secrets Found: 4",1100));s.finish(2000);assertEquals(SecretCounterState.Action.REQUEST_STATS,s.poll(3000))}
    @Test fun `negative monotonic epochs work without sentinel collision`() {val s=SecretCounterState();s.finish(-2000);assertNull(s.poll(-1001));assertEquals(SecretCounterState.Action.REQUEST_STATS,s.poll(-1000));assertEquals(2,s.readSecrets("Secrets Found: 2",-999))}
    @Test fun `a backwards supplied test clock cannot accelerate dispatch`() {val s=SecretCounterState();s.finish(1000);assertNull(s.poll(0));assertNull(s.poll(1999));assertEquals(SecretCounterState.Action.REQUEST_STATS,s.poll(2000))}
    @Test fun `run start marker is exact and formatting agnostic`() {val t="[NPC] Mort: Here, I found this map when I first entered the dungeon.";assertTrue(DungeonRunMessages.started(t));assertTrue(DungeonRunMessages.started("§a$t"));assertFalse(DungeonRunMessages.started("Party > Player: $t"));assertFalse(DungeonRunMessages.started("Dungeon starts in 1 second."))}
    @Test fun `completion accepts normal master and entrance source headers`() {for(t in listOf("The Catacombs - Floor VII"," Catacombs - Floor I","Master Mode Catacombs - Floor VI"," Master Mode The Catacombs - Floor IV ","The Catacombs - Entrance","The Catacombs - Floor 7")) assertTrue(DungeonRunMessages.ended(t),t)}
    @Test fun `completion rejects spoof prefixed and unsupported header fragments`() {for(t in listOf("Party > Player: The Catacombs - Floor VII","The Catacombs - Floor VIII","The Catacombs - Floor 0","The Catacombs - Floor X","The Catacombs - Floor VII complete","Boss defeated!","The Catacombs (F7)","Catacombs - Floor Bob")) assertFalse(DungeonRunMessages.ended(t),t)}
    @Test fun `announcement waits half a second and sends once`() {val a=SecretAnnouncement();a.schedule(100,5,true);assertNull(a.poll(599,true));assertEquals(5,a.poll(600,true));assertNull(a.poll(601,true))}
    @Test fun `announcement opt out cancels a pending message permanently`() {val a=SecretAnnouncement();a.schedule(0,7,true);assertNull(a.poll(100,false));assertNull(a.poll(1000,true))}
    @Test fun `announcement disabled at result time cannot later send`() {val a=SecretAnnouncement();a.schedule(0,7,false);assertNull(a.poll(1000,true))}
    @Test fun `announcement reset drops old run data`() {val a=SecretAnnouncement();a.schedule(0,7,true);a.reset();assertNull(a.poll(1000,true))}
    @Test fun `announcement handles zero and negative time origins`() {val a=SecretAnnouncement();a.schedule(-1000,0,true);assertNull(a.poll(-501,true));assertEquals(0,a.poll(-500,true))}
    @Test fun `counter only observes non overlay game messages including canceled path`() {val s=source("feature/SecretCounter.kt");for(t in listOf("ClientReceiveMessageEvents.GAME.register","ClientReceiveMessageEvents.GAME_CANCELED.register","if(overlay || !active()) return","!ctx.dungeon","state.reset();announcement.reset()")) assertTrue(t in s,t);assertFalse("ClientReceiveMessageEvents.CHAT.register" in s);assertFalse("Thread(" in s)}
    @Test fun `server actions have fixed commands no aliases and opt in announcements`() {val s=source("feature/SecretCounter.kt");assertEquals(1,Regex("sendCommand\\(\"showextrastats\"\\)").findAll(s).count());assertTrue("announcement.poll(now,s.autoAnnounce)" in s);assertTrue("connection.sendCommand(\"pc $" in s);assertTrue("connection.sendChat(text)" in s)}
    @Test fun `settings stay embedded and successful counter changes save immediately`() {val ui=source("ui/ArchiveDungeonUi.kt");assertTrue("host.showPanel(SettingsPanel(" in ui);assertFalse("setScreen" in ui);var saved=GeneralSettings();val m=InstantSettings(CommandProfile(),saved) {_,g->saved=g;null};assertTrue(m.updateGeneral {it.copy(features=it.features.copy(secretCounter=SecretCounterSettings(true,"party")))});assertTrue(saved.features.secretCounter.autoAnnounce);assertEquals("party",saved.features.secretCounter.channel);assertFalse(m.pending())}
    private fun requested()=SecretCounterState().also {it.finish(0);assertEquals(SecretCounterState.Action.REQUEST_STATS,it.poll(1000))}
    private fun source(path:String)=Path.of("src/client/kotlin/dev/solyanka/client/$path").toFile().readText()
}
